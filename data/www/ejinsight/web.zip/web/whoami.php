<?php
echo gethostname(); 
?>