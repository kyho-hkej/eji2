
<?php
echo 'this is index page';
?>


