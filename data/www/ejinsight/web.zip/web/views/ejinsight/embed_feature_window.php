                      <div class="feature_window">
                    
                    <div class="swiper-pagination"></div>
                    <!---- Swiper ----->
                    <div class="swiper">
                  
                        <div class="swiper-slide">
                        <div class="pic">
                            <span class="count">+4</span>
                            <img src="images/article_slide1.jpg" alt=""/>
                            </div>
                            <div class="text">由最初僅以預約訂製方式為客人提供服務，以至分別在2014年及2015年在印度新德里和孟買開設旗艦店後，品牌便積極開拓國際市場品牌，繼在2015年於紐約麥迪森大道開設了美國專門店後，早前又於2016年9月在倫敦的舊邦德街開設了專門店，為擴展歐洲市場踏出第一步。2016年11月，又於澳門美高梅酒店開設首間澳門專門店。</div>
                        </div>
                          
                        <div class="swiper-slide">
                         <div class="pic"><img src="images/article_slide2.jpg" alt=""/></div>
                         <div class="text">顯而易見，NIRAV MODI已越來越受到演藝時尚圈歡迎擁戴，這可說是亞洲高級珠品品牌一大突破，難怪品牌創辦人Nirav Modi已許下豪言要在2025年前在全球NIRAV MODI專門店總數達100家，令品牌成為世界上五大珠寶品牌之一。</div>
                        </div>
                        
                        <div class="swiper-slide">
                         <div class="pic"><img src="images/article_slide3.jpg" alt=""/></div>
                         <div class="text">Nirav Modi先生以傳統的創作理念加上創新設計，製作出別出心裁的珠寶，享譽全球。2010年11月，Nirav Modi獨特的「戈爾康達鑽石」項鏈，成為首位登上佳士得拍賣目錄封面的印度珠寶家。NIRAV MODI的珠寶亦經常出現在佳士得及蘇富比拍賣中。</div>
                        </div>
                        
                        <div class="swiper-slide">
                         <div class="pic"><img src="images/article_slide4.jpg" alt=""/></div>
                         <div class="text">品牌便積極開拓國際市場品牌，繼在2015年於紐約麥迪森大道開設了美國專門店後，早前又於2016年9月在倫敦的舊邦德街開設了專門店，為擴展歐洲市場踏出第一步。</div>
                        </div>
                        
                        
                  
                        
                    </div>
                    <!---- Swiper ----->
                    
                   </div>
                      