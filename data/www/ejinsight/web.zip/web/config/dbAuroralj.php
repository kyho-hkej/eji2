<?php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=www2.cluster-ro-cm5gikysdx5r.ap-southeast-1.rds.amazonaws.com;dbname=lj',
    'username' => 'hkej_admin',
    'password' => 'fr0nt1sql',
    'charset' => 'utf8mb4',

];

