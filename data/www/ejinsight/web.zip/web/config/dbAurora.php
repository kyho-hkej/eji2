<?php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=www2.cluster-cm5gikysdx5r.ap-southeast-1.rds.amazonaws.com;dbname=eji',
    'username' => 'hkej_admin',
    'password' => 'fr0nt1sql',
    'charset' => 'utf8mb4',

];

